let x;//declara a função de x
let y;//declara a função de y

function setup() {
  createCanvas(400, 400);//criar a tela
  x = random(400);//posição aleatória de x
  x = int(x);// posição variável x
  y = random(400);//posição aleatória y
  y = int(y);//posição variável y
}

function draw() {
  background(220);//define a cor do plano de fundo
 circle(x, y, 10);//declara o círculo e o seu tamanho
  console.log(mouseX, x);
    
  if(mouseX == x) {
    text('Encontrei!', 200, 200);
  }
}

function draw() {
    background(220);
    let distanciaX;//distancia da bolinha no eixo x
    let distanciaY;//distancia da bolinha no eixo y
    let distancia;// distancia da hipotenusa no triangulo
    distanciaX = mouseX - x;//distancia da bolinha no eixo x
    distanciaY = mouseY - y;//distancia da bolinha no eixo y
    distancia = sqrt(distanciaX * distanciaX + distanciaY * distanciaY);//distancia do mouse até o circulo
    
   circle(x, y, 50);//define o tamanho e a posição da bolinha
    console.log(distancia);//define a distancia e imprime no terminal
    
    if (mouseX == x && mouseY == y) {//se a posição do mouse for a mesma da bolinha
        text('Encontrei!', 200, 200);//imprime o texto "encontrei" no canva e sua localização
        noLoop();//logo após isso ocorrer, encerra-se o loop e a verificação do código- fim do jogo.
    }
}